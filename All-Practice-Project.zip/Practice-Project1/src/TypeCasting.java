
public class TypeCasting {

	public static void main(String[] args) {
        int intValue = 23000;
        double doubleValue = intValue; // Implicit conversion from int to double

        System.out.println("Implicit Type Casting :");
        System.out.println("int value: " + intValue);
        System.out.println("double value: " + doubleValue);

        double doubleNum = 563.231;
        int intNum = (int) doubleNum; // Explicit conversion from double to int

        System.out.println("\nExplicit Type Casting :");
        System.out.println("double value: " + doubleNum);
        System.out.println("int value: " + intNum);
    }

}


