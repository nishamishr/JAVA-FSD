package Constructor;
class Person {
	private String name;
	private int age;
	
// Default Constructor
	public Person() {
		this.name = "Unknown";
		this.age = 0;
 }

 // Parameterized Constructor
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
 }

 // Constructor Overloading
	 public Person(String name) {
		 this.name = name;
		 this.age = 0;
}

	 public void displayInfo() {
		 System.out.println("Name: " + name);
		 System.out.println("Age: " + age);
	}
}

public class Constructor {
		    public static void main(String[] args) {
		        // Using the default constructor
		        Person person1 = new Person();
		        System.out.println("Using Default Constructor:");
		        person1.displayInfo();
		        System.out.println();

		        // Using the parameterized constructor
		        Person person2 = new Person("Alice", 25);
		        System.out.println("Using Parameterized Constructor:");
		        person2.displayInfo();
		        System.out.println();

		        // Using constructor overloading
		        Person person3 = new Person("Bob");
		        System.out.println("Using Constructor Overloading:");
		        person3.displayInfo();
		   }
		
}


