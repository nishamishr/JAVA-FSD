// first.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent {
  public product: any; // Declare the 'product' property

  constructor() {
    // Initialize the 'product' property if needed
    this.product = {
      productName: 'Example Product',
      price: 10.99
    };
  }

  toggleImage() {
    // Implement the 'toggleImage' method logic here
  }
}
